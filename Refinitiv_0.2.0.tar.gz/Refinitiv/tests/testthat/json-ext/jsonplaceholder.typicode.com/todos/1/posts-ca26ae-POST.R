structure(list(
  method = "POST", url = "https://jsonplaceholder.typicode.com/todos/1/posts",
  status_code = 201L, headers = structure(list(
    date = "Wed, 25 Feb 2026 13:07:50 GMT",
    `content-type` = "application/json; charset=utf-8", `content-length` = "309",
    location = "https://jsonplaceholder.typicode.com/todos/1/posts/101",
    `access-control-allow-credentials` = "true", `access-control-expose-headers` = "Location",
    `cache-control` = "no-cache", etag = "W/\"135-2zMhKoGfBCsaU12ThdXaY+tqng8\"",
    expires = "-1", nel = "{\"report_to\":\"heroku-nel\",\"response_headers\":[\"Via\"],\"max_age\":3600,\"success_fraction\":0.01,\"failure_fraction\":0.1}",
    pragma = "no-cache", `report-to` = "{\"group\":\"heroku-nel\",\"endpoints\":[{\"url\":\"https://nel.heroku.com/reports?s=yRWvh4XB0u1kyE6iDlDIFC%2FkzFVqR8gctlX1oKBOGHc%3D\\u0026sid=e11707d5-02a7-43ef-b45e-2cf4d2036f7d\\u0026ts=1772024870\"}],\"max_age\":3600}",
    `reporting-endpoints` = "heroku-nel=\"https://nel.heroku.com/reports?s=yRWvh4XB0u1kyE6iDlDIFC%2FkzFVqR8gctlX1oKBOGHc%3D&sid=e11707d5-02a7-43ef-b45e-2cf4d2036f7d&ts=1772024870\"",
    server = "cloudflare", vary = "Origin, X-HTTP-Method-Override, Accept-Encoding",
    via = "2.0 heroku-router", `x-content-type-options` = "nosniff",
    `x-powered-by` = "Express", `x-ratelimit-limit` = "1000",
    `x-ratelimit-remaining` = "999", `x-ratelimit-reset` = "1772024920",
    `cf-cache-status` = "DYNAMIC", `cf-ray` = "9d376d923c0fb9a1-BRU",
    `alt-svc` = "h3=\":443\"; ma=86400"
  ), class = "httr2_headers"),
  body = charToRaw("{\n  \"Entity\": {\n    \"E\": \"DataGrid_StandardAsync\",\n    \"W\": {\n      \"requests\": [\n        {\n          \"instruments\": [\n            \"TSLA.O\"\n          ],\n          \"fields\": [\n            {\n              \"name\": \"TR.RICCode\"\n            }\n          ]\n        }\n      ]\n    }\n  },\n  \"todoId\": \"1\",\n  \"id\": 101\n}"),
  timing = c(
    redirect = 0, namelookup = 0.163171, connect = 0.186814,
    pretransfer = 0.217822, starttransfer = 0.487159, total = 0.487312
  ), cache = new.env(parent = emptyenv())
), class = "httr2_response")
