utils::globalVariables(c(".EikonApplicationPort"))
